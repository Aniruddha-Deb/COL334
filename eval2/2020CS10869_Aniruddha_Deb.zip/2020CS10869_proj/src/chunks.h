#include <iostream> //for std::cout
#include <string.h> //for std::string
// #include <bits/stdc++.h>
#include <map>
#include <cstdlib>
#ifndef SIDE_LIBRARY 
#define SIDE_LIBRARY 
using namespace std;
 
size_t get_hash(string s);
pair<string, size_t> get_chunk(int id);
 
#endif 